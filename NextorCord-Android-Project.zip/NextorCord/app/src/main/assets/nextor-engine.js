/* NEXTOR audio interception engine. WebAudio processing is bounded by a final limiter. */
(() => {
  'use strict';
  if (window.__NEXTOR_INSTALLED__) return;
  window.__NEXTOR_INSTALLED__ = true;
  const log = (...a) => { try { console.log('[NEXTOR]', ...a); window.NextorNative?.log(a.join(' ')); } catch (_) {} };
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, Number.isFinite(+v) ? +v : lo));
  const defaults = {
    preampDb: 24, boostPlus: false, mode: 'EXTENDED', drive: 0, clipper: 'soft',
    cascade: false, gate: true, gateThreshold: -52, gateAttack: 8, gateRelease: 140,
    gateHold: 80, spectralNR: false, mudCut: -3, presence: 3, bypass: false,
    battleBlend: 0, upward: 0, targetLufs: -9, limitBreak: false, bass: 0, mid: 0,
    treble: 0, air: 0, width: 100, wider: false, haas: false, autopan: false,
    effect: 'none', reverb: 0, delay: 0, pitch: 0, formant: 0, position: 'in-head',
    exciter: 0, boostBass: false
  };
  let cfg = {...defaults}, contexts = new Set(), hooked = false, originalGetUserMedia;
  const meters = { rms: 0, peak: 0, clips: 0, momentary: -120, shortTerm: -120, integrated: -120 };
  function gainFromDb(db) {
    const raw = Math.pow(10, clamp(db, 0, 400) / 20);
    return Math.fround(Math.min(raw, 3.402823466e38));
  }
  function curveFor(mode, amount) {
    const n = 2048, curve = new Float32Array(n), d = clamp(amount, 0, 200) / 100;
    for (let i=0;i<n;i++) {
      const x = i * 2 / (n-1) - 1;
      let y = x;
      switch(mode) {
        case 'hard': y = clamp(x * (1 + d*8), -1, 1); break;
        case 'warm': y = Math.tanh(x * (1 + d*2)) * 0.92; break;
        case 'punch': y = Math.tanh(x * (1 + d*4)); break;
        case 'crush': y = Math.round(x * (8 + d*56)) / (8 + d*56); break;
        case 'wavefolder': y = Math.sin(x * (1 + d*8)); break;
        case 'tube': y = Math.tanh(x * (1 + d*3)) * (0.9 + 0.1*Math.cos(x*3)); break;
        case 'diode': y = x < 0 ? x*0.35 : Math.tanh(x*(1+d*5)); break;
        case 'tanh': y = Math.tanh(x*(1+d*5)); break;
        default: y = Math.tanh(x*(1+d*3));
      }
      curve[i] = y;
    }
    return curve;
  }
  function makeEngine(stream) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) { log('WebAudio unavailable; raw mic retained'); return null; }
    const ctx = new AC({ latencyHint: 'interactive' });
    contexts.add(ctx);
    const source = ctx.createMediaStreamSource(stream);
    const hp = ctx.createBiquadFilter(); hp.type='highpass'; hp.frequency.value=80; hp.Q.value=0.707;
    const gate = ctx.createGain(); gate.gain.value=1;
    const pre = ctx.createGain(), boost = ctx.createGain();
    const mud = ctx.createBiquadFilter(); mud.type='peaking'; mud.frequency.value=300; mud.Q.value=0.8;
    const presence = ctx.createBiquadFilter(); presence.type='peaking'; presence.frequency.value=3500; presence.Q.value=0.8;
    const shaper = ctx.createWaveShaper(); shaper.oversample='4x';
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value=-24; comp.knee.value=24; comp.ratio.value=4; comp.attack.value=0.006; comp.release.value=0.12;
    const battle = ctx.createDynamicsCompressor(); battle.threshold.value=-42; battle.ratio.value=12; battle.attack.value=0.003; battle.release.value=0.18;
    const battleMix = ctx.createGain(), dryMix = ctx.createGain();
    const upward = ctx.createGain();
    const bass = ctx.createBiquadFilter(); bass.type='lowshelf'; bass.frequency.value=120;
    const mid = ctx.createBiquadFilter(); mid.type='peaking'; mid.frequency.value=1000; mid.Q.value=0.7;
    const treble = ctx.createBiquadFilter(); treble.type='highshelf'; treble.frequency.value=5000;
    const air = ctx.createBiquadFilter(); air.type='highshelf'; air.frequency.value=11000;
    const limiter = ctx.createDynamicsCompressor(); limiter.threshold.value=-3; limiter.knee.value=0; limiter.ratio.value=20; limiter.attack.value=0.001; limiter.release.value=0.08;
    const finalGain = ctx.createGain(); finalGain.gain.value=0.98;
    const analyser = ctx.createAnalyser(); analyser.fftSize=2048;
    const dest = ctx.createMediaStreamDestination();
    source.connect(hp); hp.connect(gate); gate.connect(pre); pre.connect(boost);
    boost.connect(mud); mud.connect(presence); presence.connect(shaper);
    shaper.connect(comp); comp.connect(dryMix); comp.connect(battle); battle.connect(battleMix);
    dryMix.connect(upward); battleMix.connect(upward); upward.connect(bass);
    bass.connect(mid); mid.connect(treble); treble.connect(air); air.connect(limiter);
    limiter.connect(finalGain); finalGain.connect(analyser); analyser.connect(dest);
    let gateOpen = true, lastAbove = 0, rampTimer = null;
    const buf = new Float32Array(analyser.fftSize);
    function meter() {
      try {
        analyser.getFloatTimeDomainData(buf);
        let sum=0, peak=0;
        for (const x of buf) { sum += x*x; peak=Math.max(peak,Math.abs(x)); }
        const rms=Math.sqrt(sum/buf.length);
        meters.rms=rms; meters.peak=peak;
        meters.momentary = rms > 1e-7 ? 20*Math.log10(rms) : -120;
        meters.shortTerm = meters.shortTerm*0.85 + meters.momentary*0.15;
        meters.integrated = meters.integrated*0.995 + meters.momentary*0.005;
        if (peak >= 0.999) meters.clips++;
      } catch(e) { log('meter error',e.message); }
      requestAnimationFrame(meter);
    }
    meter();
    function apply() {
      const now=ctx.currentTime;
      const ext = cfg.mode === 'EXTENDED';
      const baseDb = ext ? Math.min(cfg.preampDb,60) : cfg.preampDb;
      let gain = gainFromDb(baseDb);
      const extra = Math.max(0, cfg.preampDb-60);
      if (cfg.mode === 'LITERAL') gain = gainFromDb(cfg.preampDb);
      pre.gain.cancelScheduledValues(now);
      pre.gain.setValueAtTime(pre.gain.value, now);
      pre.gain.linearRampToValueAtTime(Math.min(gain, 1000), now+0.05);
      boost.gain.setTargetAtTime(cfg.boostPlus ? 15.8489 : 1, now, 0.025);
      mud.gain.setTargetAtTime(cfg.mudCut,now,0.03);
      presence.gain.setTargetAtTime(cfg.presence + extra*0.025,now,0.03);
      const drive = clamp(cfg.drive + extra*1.25,0,500);
      shaper.curve=curveFor(cfg.clipper,drive);
      battleMix.gain.setTargetAtTime(clamp(cfg.battleBlend,0,100)/100,now,0.03);
      dryMix.gain.setTargetAtTime(1-clamp(cfg.battleBlend,0,100)/100,now,0.03);
      upward.gain.setTargetAtTime(1+clamp(cfg.upward,0,12)/12,now,0.03);
      bass.gain.setTargetAtTime(clamp(cfg.bass,-24,24)+(cfg.boostBass?6:0),now,0.03);
      mid.gain.setTargetAtTime(clamp(cfg.mid,-24,24),now,0.03);
      treble.gain.setTargetAtTime(clamp(cfg.treble,-24,24),now,0.03);
      air.gain.setTargetAtTime(clamp(cfg.air,-24,24),now,0.03);
      finalGain.gain.setTargetAtTime(0.98,now,0.01);
      limiter.threshold.value = cfg.limitBreak ? -1.5 : -3;
      // Extended range is mapped to bounded coloration/makeup, never unbounded sample amplitude.
      if (ext && extra>0) {
        const makeup = 1 + extra/340;
        pre.gain.setTargetAtTime(Math.min(gain*makeup,1000),now,0.05);
      }
      if (cfg.bypass) { pre.gain.setTargetAtTime(1,now,0.01); shaper.curve=null; }
    }
    const gateLoop = () => {
      if (!cfg.gate) { gate.gain.setTargetAtTime(1,ctx.currentTime,0.02); }
      else {
        analyser.getFloatTimeDomainData(buf);
        let s=0; for(const x of buf) s+=x*x;
        const level=20*Math.log10(Math.sqrt(s/buf.length)+1e-9);
        const t=performance.now();
        if(level>cfg.gateThreshold){ gateOpen=true; lastAbove=t; }
        else if(t-lastAbove>cfg.gateHold){ gateOpen=false; }
        gate.gain.setTargetAtTime(gateOpen?1:0.0001,ctx.currentTime,gateOpen?cfg.gateAttack/1000:cfg.gateRelease/1000);
      }
      setTimeout(gateLoop,25);
    };
    gateLoop(); apply();
    return {ctx, dest, apply, source};
  }
  function patchStream(stream) {
    try {
      if (!stream || !stream.getAudioTracks().length) return stream;
      const engine=makeEngine(stream);
      if (!engine) return stream;
      const output=engine.dest.stream;
      const tracks=output.getAudioTracks();
      if (!tracks.length) return stream;
      // Preserve original video tracks; replace only audio.
      const combined = new MediaStream([...stream.getVideoTracks(), ...tracks]);
      stream.getAudioTracks().forEach(t => t.addEventListener('ended',()=>tracks.forEach(x=>x.stop())));
      return combined;
    } catch(e) { log('patch stream failed; raw mic retained',e.stack||e); return stream; }
  }
  function install() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || hooked) return;
    originalGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
    try {
      navigator.mediaDevices.getUserMedia = async constraints => {
        const stream = await originalGetUserMedia(constraints);
        if (!constraints || !constraints.audio) return stream;
        return patchStream(stream);
      };
      hooked=true; log('getUserMedia hook installed');
    } catch(e) { log('hook failed',e.message); }
  }
  window.NextorEngine = {
    setConfig(update) {
      try {
        cfg={...cfg,...update};
        contexts.forEach(c=>{ /* node configs are applied by active graph closures */ });
        log('config updated',JSON.stringify(update));
        window.dispatchEvent(new CustomEvent('nextor-config',{detail:cfg}));
      } catch(e) { log('config error',e.message); }
    },
    getConfig:()=>({...cfg}),
    getMeters:()=>({...meters}),
    panic() { cfg.preampDb=0; cfg.boostPlus=false; cfg.drive=0; cfg.battleBlend=0; cfg.bypass=false; window.dispatchEvent(new CustomEvent('nextor-panic')); log('panic reset'); },
    install,
    presets: {
      Clean:{preampDb:12,drive:0,gate:true,targetLufs:-16},
      Loud:{preampDb:30,drive:12,gate:true,targetLufs:-9},
      'Max Loud':{preampDb:42,drive:40,gate:true,targetLufs:-6},
      Ultra:{preampDb:48,drive:65,gate:true,targetLufs:-4},
      'Bass Boss':{preampDb:30,bass:8,boostBass:true,drive:20},
      Radio:{preampDb:24,mudCut:-5,presence:5,treble:3},
      Whisper:{preampDb:36,gate:true,gateThreshold:-62,drive:0},
      Robot:{preampDb:24,clipper:'crush',drive:90}
    }
  };
  // Config updates are shared with each graph, including reconnect-created graphs.
  const activeGraphs=[];
  const originalMakeEngine=makeEngine;
  makeEngine = function(s) {
    const g=originalMakeEngine(s);
    if(g) {
      const listener=()=>{ try { g.apply(); } catch(e){log('reconfigure failed',e.message);} };
      window.addEventListener('nextor-config',listener);
      window.addEventListener('nextor-panic',()=>{g.apply();});
      activeGraphs.push(g);
    }
    return g;
  };
  function addFab() {
    if(document.getElementById('nextor-fab')) return;
    const b=document.createElement('button'); b.id='nextor-fab'; b.textContent='N';
    Object.assign(b.style,{position:'fixed',right:'16px',bottom:'110px',zIndex:2147483647,width:'54px',height:'54px',borderRadius:'50%',border:'2px solid #ff5252',background:'#171010',color:'#ff5252',font:'bold 22px sans-serif',boxShadow:'0 4px 20px #000',touchAction:'none'});
    let sx=0,sy=0, moved=false;
    b.addEventListener('pointerdown',e=>{sx=e.clientX;sy=e.clientY;moved=false;b.setPointerCapture(e.pointerId);});
    b.addEventListener('pointermove',e=>{if(e.buttons){const dx=e.clientX-sx,dy=e.clientY-sy;if(Math.abs(dx)+Math.abs(dy)>5)moved=true;b.style.right='auto';b.style.left=(b.offsetLeft+dx)+'px';b.style.top=(b.offsetTop+dy)+'px';sx=e.clientX;sy=e.clientY;}});
    b.addEventListener('click',()=>{if(!moved){try{window.NextorNative?.openControls();}catch(_){}}});
    document.body.appendChild(b);
  }
  function watch() {
    install(); if(document.body) addFab();
    const obs=new MutationObserver(()=>{install();addFab();});
    if(document.documentElement) obs.observe(document.documentElement,{childList:true,subtree:true});
    setInterval(install,3000);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',watch,{once:true}); else watch();
  log('engine booted');
})();
