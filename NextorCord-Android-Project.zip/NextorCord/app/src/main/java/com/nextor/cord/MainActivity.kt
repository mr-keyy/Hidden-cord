package com.nextor.cord

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var preampDb = 24
    private var engineReady = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestRuntimePermissions()

        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(9, 9, 9))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.databaseEnabled = true
            settings.userAgentString = settings.userAgentString +
                " Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            addJavascriptInterface(NextorBridge(), "NextorNative")
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val allowed = request.resources.filter {
                            it == PermissionRequest.RESOURCE_AUDIO_CAPTURE
                        }.toTypedArray()
                        if (allowed.isNotEmpty() && hasAudioPermission()) request.grant(allowed)
                        else request.deny()
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val host = request.url.host ?: return true
                    return !(host == "discord.com" || host.endsWith(".discord.com") ||
                        host == "discordapp.com" || host.endsWith(".discordapp.com"))
                }
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    injectEngine()
                    engineReady = true
                }
            }
        }
        setContentView(web)
        web.loadUrl("https://discord.com/app")
        startMicService()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                // The user chooses whether to exempt the app; no automatic settings mutation.
                Toast.makeText(this, "For longer background sessions, review battery optimization settings.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun requestRuntimePermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 41)
    }

    private fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startMicService() {
        if (!hasAudioPermission()) return
        try {
            val intent = Intent(this, MicKeepAliveService::class.java)
            ContextCompat.startForegroundService(this, intent)
        } catch (e: Exception) {
            android.util.Log.w("NEXTOR", "Foreground microphone service could not start: ${e.message}")
        }
    }

    private fun injectEngine() {
        val js = assets.open("nextor-engine.js").bufferedReader().use { it.readText() }
        web.evaluateJavascript(js, null)
    }

    inner class NextorBridge {
        @android.webkit.JavascriptInterface
        fun log(message: String) { android.util.Log.d("NEXTOR", message.take(1500)) }
        @android.webkit.JavascriptInterface
        fun openControls() { runOnUiThread { showControls() } }
        @android.webkit.JavascriptInterface
        fun setPreamp(value: Int) { preampDb = value.coerceIn(0, 72) }
    }

    private fun showControls() {
        val dialog = BottomSheetDialog(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(18, 18, 18))
        }
        val heading = TextView(this).apply {
            text = "NEXTOR CONTROL DECK"
            textSize = 18f
            setTextColor(android.graphics.Color.WHITE)
        }
        layout.addView(heading)
        val valueText = TextView(this).apply {
            text = "PREAMP  $preampDb dB"
            textSize = 15f
            setTextColor(0xFFFF5252.toInt())
            setPadding(0, 18, 0, 8)
        }
        layout.addView(valueText)
        val slider = SeekBar(this).apply {
            max = 72
            progress = preampDb
        }
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    preampDb = progress
                    valueText.text = "PREAMP  $preampDb dB"
                    web.evaluateJavascript("window.NextorEngine && window.NextorEngine.setConfig({preampDb:$preampDb})", null)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        layout.addView(slider)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun action(label: String, js: String) {
            val b = Button(this).apply { text = label; setOnClickListener { web.evaluateJavascript(js, null) } }
            row.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        action("PANIC", "window.NextorEngine && window.NextorEngine.panic()")
        action("BYPASS", "window.NextorEngine && window.NextorEngine.setConfig({bypass:true})")
        action("LIVE", "window.NextorEngine && window.NextorEngine.setConfig({bypass:false})")
        layout.addView(row)
        val note = TextView(this).apply {
            text = "Audio processing starts when Discord requests microphone access. Keep this app foregrounded for reliable voice sessions."
            setTextColor(0xFFAAAAAA.toInt()); textSize = 12f; setPadding(0, 14, 0, 0)
        }
        layout.addView(note)
        dialog.setContentView(layout)
        dialog.show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            preampDb = (preampDb + if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) 2 else -2).coerceIn(0, 72)
            if (::web.isInitialized) web.evaluateJavascript(
                "window.NextorEngine && window.NextorEngine.setConfig({preampDb:$preampDb})", null
            )
            Toast.makeText(this, "Nextor preamp: $preampDb dB", Toast.LENGTH_SHORT).show()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        if (::web.isInitialized) { web.stopLoading(); web.destroy() }
        super.onDestroy()
    }
}
