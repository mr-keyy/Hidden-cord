# Nextor Cord

Android WebView shell for Discord Web (`https://discord.com/app`) with a JavaScript microphone-processing interception layer.

## Important engineering limits

- Discord Web is not a supported substitute for the native Discord Android client. Discord can change its web app, microphone capture path, or browser checks at any time.
- WebView's `getUserMedia` interception is best-effort. This project replaces the audio tracks returned by `getUserMedia`; it cannot guarantee interception of every Discord voice implementation or survive every reconnect/channel transition.
- Android restricts microphone foreground services. Start the app while visible, grant microphone permission, and keep its ongoing notification. Android 14+ may reject microphone service starts from the background.
- The service is not a guarantee that Discord voice continues with the display off. OEM power management, WebView lifecycle, Discord behavior, and Android foreground-service policy still apply.
- The current DSP is a practical WebAudio starter chain, not a studio-grade mastering system. The UI exposes a deliberately bounded set of controls. LUFS readings are RMS-derived estimates, not standards-compliant BS.1770 LUFS; the compressor is not a true look-ahead/true-peak limiter.
- 400 dB is not a physically useful mic setting. EXTENDED mode caps actual preamp at 60 dB and maps the excess into bounded coloration. LITERAL mode is numerically clamped and still passes through the final dynamics stage. Excessive loudness can damage hearing and cause distortion for other people.
- `onPermissionRequest` grants only audio capture after Android's RECORD_AUDIO permission is granted. This is safer and more reliable than blindly granting every WebView resource.
- Battery-optimization exemption is user-controlled. The app does not silently change system power settings.

## Build

Requirements: Android Studio Ladybug or newer, JDK 17, Android SDK Platform 35, Build Tools 35.x.

1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Connect an Android device with USB debugging enabled, or use an emulator with microphone support.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Command line:
```bash
./gradlew assembleDebug
```

## Sign a release APK

Create a private signing key (keep it secret and backed up):
```bash
keytool -genkeypair -v -keystore nextor-release.jks -alias nextor -keyalg RSA -keysize 2048 -validity 10000
```

Build an unsigned release:
```bash
./gradlew assembleRelease
```

Sign it with Android SDK Build Tools (replace paths and alias as appropriate):
```bash
$ANDROID_HOME/build-tools/35.0.0/apksigner sign \
  --ks nextor-release.jks \
  --ks-key-alias nextor \
  --out NextorCord-release.apk \
  app/build/outputs/apk/release/app-release-unsigned.apk
```

Verify:
```bash
$ANDROID_HOME/build-tools/35.0.0/apksigner verify --verbose NextorCord-release.apk
```

Never share the keystore or its passwords. For Play distribution, use a properly configured release signing process and review current Play target API requirements.

## Permissions and controls

- RECORD_AUDIO: required for mic capture.
- INTERNET: Discord Web access.
- MODIFY_AUDIO_SETTINGS: declared for audio-session integration.
- FOREGROUND_SERVICE / FOREGROUND_SERVICE_MICROPHONE: ongoing voice-session notification.
- POST_NOTIFICATIONS: notification on Android 13+.
- WAKE_LOCK: bounded partial wake lock while the service runs.

The floating red `N` opens a native control sheet. Volume Up/Down changes the preamp by 2 dB while this activity is active. Panic resets preamp and drive.
